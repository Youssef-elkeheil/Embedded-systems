/**
 ******************************************************************************
 * @file        RCC_config.c
 * @author      Youssef EL_KAHEIL
 * @date        8/7/2022
 * @brief       This file contains struct defintions.
 *              User can change the values.
 ******************************************************************************
 **/


