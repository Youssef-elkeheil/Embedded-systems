/**
 ******************************************************************************
 * @file        RCC_config.h
 * @author      Youssef EL_KAHEIL
 * @date        8/7/2022
 * @brief       This file contains configeration macros and struct declaration.
 *              User can change the values in this file when needed.
 ******************************************************************************
 **/
#ifndef RCC_CONFIG_H
#define RCC_CONFIG_H

























#endif