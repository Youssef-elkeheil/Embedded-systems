/**
 ******************************************************************************
 * @file        RCC_interface.h
 * @author      Youssef EL_KAHEIL
 * @date        8/7/2022
 * @brief       This file contains functions' declarations
 *              this is the only file to be included when RCC is needed 
 * @attention   don't change anything in this file       
 ******************************************************************************
 **/

#ifndef RCC_INTERFACE_H
#define RCC_INTERFACE_H




















#endif