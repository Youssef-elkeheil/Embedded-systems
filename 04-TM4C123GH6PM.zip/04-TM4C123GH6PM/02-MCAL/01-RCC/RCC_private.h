/**
 ******************************************************************************
 * @file        RCC_private.h
 * @author      Youssef EL_KAHEIL
 * @date        8/7/2022
 * @brief       This file is used by the developer
 * @attention   don't change anything in this file
 ******************************************************************************
 **/

#ifndef RCC_PRIVATE_H
#define RCC_PRIVATE_H






















#endif