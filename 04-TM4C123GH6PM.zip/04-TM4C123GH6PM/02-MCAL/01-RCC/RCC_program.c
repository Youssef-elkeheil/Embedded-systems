/**
 ******************************************************************************
 * @file        RCC_program.c
 * @author      Youssef EL_KAHEIL
 * @date        8/7/2022
 * @brief       This file contains functions' defintions
 * @attention   don't change anything in this file
 ******************************************************************************
 **/

#include "RCC_interface.h"
#include "RCC_registers.h"
#include "RCC_config.h"
#include "RCC_private.h"


