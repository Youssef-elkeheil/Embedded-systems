/**
 ******************************************************************************
 * @file        RCC_registers.h
 * @author      Youssef EL_KAHEIL
 * @date        8/7/2022
 * @brief       This file contains the addresses of the registers
 * @attention   don't change anything in this file
 ******************************************************************************
 **/

#ifndef RCC_REGISTERS_H
#define RCC_REGISTERS_H


























#endif